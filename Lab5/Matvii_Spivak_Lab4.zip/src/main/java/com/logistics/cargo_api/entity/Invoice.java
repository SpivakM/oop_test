package com.logistics.cargo_api.entity;

import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

@Entity
@Table(name = "invoices")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Invoice {

    private static final DateTimeFormatter FMT = DateTimeFormatter.ofPattern("dd.MM.yyyy HH:mm");

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @OneToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "order_id", nullable = false, unique = true)
    private Order order;

    @Column(nullable = false)
    private double fuelCost;

    @Column(nullable = false)
    private double amortizationCost;

    @Column(nullable = false)
    private double cargoSurcharge;

    @Column(nullable = false)
    private double totalAmount;

    @Column(nullable = false)
    private LocalDateTime issuedAt;

    public String getDetailedInfo() {
        return "╔══════════════════════════════════════════════════════╗\n" +
                "║              РАХУНОК-ФАКТУРА (ІНВОЙС)                ║\n" +
                "╠══════════════════════════════════════════════════════╣\n" +
                String.format("║  Інвойс №%-6d  Замовлення №%-6d  Дата: %-10s  ║%n",
                        id, order.getId(), issuedAt.format(FMT)) +
                "╠══════════════════════════════════════════════════════╣\n" +
                String.format("║  Маршрут:  %-41s║%n",
                        order.getRoute().getOrigin() + " → " + order.getRoute().getDestination()) +
                String.format("║  Відстань: %-35.0f км  ║%n", order.getRoute().getDistanceKm()) +
                String.format("║  Транспорт: %-40s║%n", order.getVehicle().getLicensePlate()) +
                String.format("║  Водій:    %-41s║%n", order.getDriver().getFullName()) +
                "╠══════════════════════════════════════════════════════╣\n" +
                String.format("║  Вартість палива:        %20.2f грн  ║%n", fuelCost) +
                String.format("║  Амортизація:            %20.2f грн  ║%n", amortizationCost) +
                String.format("║  Надбавка за тип вантажу:%20.2f грн  ║%n", cargoSurcharge) +
                "╠══════════════════════════════════════════════════════╣\n" +
                String.format("║  РАЗОМ ДО СПЛАТИ:        %20.2f грн  ║%n", totalAmount) +
                "╚══════════════════════════════════════════════════════╝\n";
    }
}