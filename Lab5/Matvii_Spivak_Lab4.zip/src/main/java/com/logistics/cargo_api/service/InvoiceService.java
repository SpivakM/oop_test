package com.logistics.cargo_api.service;

import com.logistics.cargo_api.entity.Cargo;
import com.logistics.cargo_api.entity.Invoice;
import com.logistics.cargo_api.entity.Order;
import com.logistics.cargo_api.entity.enums.CargoType;
import com.logistics.cargo_api.entity.enums.OrderStatus;
import com.logistics.cargo_api.exception.EntityNotFoundException;
import com.logistics.cargo_api.exception.InvalidStatusTransitionException;
import com.logistics.cargo_api.repository.InvoiceRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class InvoiceService {

    private static final double FUEL_PRICE_PER_LITRE = 54.0;

    private static final double AMORTIZATION_PER_KM = 8.5;

    private static final double FRAGILE_SURCHARGE     = 0.20;

    private static final double DANGEROUS_SURCHARGE   = 0.50;

    private static final double REFRIGERATED_SURCHARGE = 0.30;

    private final InvoiceRepository invoiceRepository;
    private final OrderService      orderService;

    @Transactional
    public Invoice generateInvoice(Long orderId) {
        if (invoiceRepository.existsByOrderId(orderId)) {
            return invoiceRepository.findByOrderId(orderId)
                    .orElseThrow(() -> new EntityNotFoundException("Інвойс для замовлення", orderId));
        }

        Order order = orderService.findById(orderId);

        if (order.getStatus() == OrderStatus.PENDING) {
            throw new InvalidStatusTransitionException(
                    "Інвойс можна сформувати лише після відправлення замовлення (не для PENDING)");
        }
        if (order.getStatus() == OrderStatus.CANCELLED) {
            throw new InvalidStatusTransitionException(
                    "Інвойс не може бути сформований для скасованого замовлення");
        }

        double distanceKm     = order.getRoute().getDistanceKm();
        double consumption    = order.getVehicle().getFuelConsumptionPer100km();

        double fuelCost        = distanceKm * (consumption / 100.0) * FUEL_PRICE_PER_LITRE;
        double amortizationCost = distanceKm * AMORTIZATION_PER_KM;

        double baseCost        = fuelCost + amortizationCost;
        double cargoSurcharge  = calculateCargoSurcharge(order, baseCost);

        double totalAmount     = baseCost + cargoSurcharge;

        Invoice invoice = Invoice.builder()
                .order(order)
                .fuelCost(fuelCost)
                .amortizationCost(amortizationCost)
                .cargoSurcharge(cargoSurcharge)
                .totalAmount(totalAmount)
                .issuedAt(LocalDateTime.now())
                .build();

        return invoiceRepository.save(invoice);
    }

    double calculateCargoSurcharge(Order order, double baseCost) {
        double maxSurchargeRate = 0.0;
        for (Cargo cargo : order.getCargos()) {
            double rate = switch (cargo.getCargoType()) {
                case DANGEROUS    -> DANGEROUS_SURCHARGE;
                case REFRIGERATED -> REFRIGERATED_SURCHARGE;
                case FRAGILE      -> FRAGILE_SURCHARGE;
                case STANDARD     -> 0.0;
            };
            if (rate > maxSurchargeRate) {
                maxSurchargeRate = rate;
            }
        }
        return baseCost * maxSurchargeRate;
    }

    @Transactional(readOnly = true)
    public Optional<Invoice> findByOrderId(Long orderId) {
        return invoiceRepository.findByOrderId(orderId);
    }

    @Transactional(readOnly = true)
    public Invoice findById(Long id) {
        return invoiceRepository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("Інвойс", id));
    }
}