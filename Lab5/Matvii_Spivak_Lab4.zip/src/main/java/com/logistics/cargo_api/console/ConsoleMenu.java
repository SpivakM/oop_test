package com.logistics.cargo_api.console;

import com.logistics.cargo_api.entity.*;
import com.logistics.cargo_api.entity.enums.*;
import com.logistics.cargo_api.service.*;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.Scanner;


@Component
@RequiredArgsConstructor
public class ConsoleMenu {

    private final CargoService   cargoService;
    private final VehicleService vehicleService;
    private final DriverService  driverService;
    private final RouteService   routeService;
    private final OrderService   orderService;
    private final InvoiceService invoiceService;

    private final Scanner scanner = new Scanner(System.in);


    public void run() {
        printBanner();
        boolean running = true;
        while (running) {
            printMainMenu();
            int choice = readInt("Ваш вибір: ");
            System.out.println();
            switch (choice) {
                case 1  -> warehouseMenu();
                case 2  -> vehicleMenu();
                case 3  -> driverMenu();
                case 4  -> routeMenu();
                case 5  -> orderMenu();
                case 6  -> invoiceMenu();
                case 0  -> { running = false; printGoodbye(); }
                default -> warn("Невірний вибір. Спробуйте ще раз.");
            }
        }
    }


    private void printBanner() {
        System.out.println("""
                ╔══════════════════════════════════════════════════════════╗
                ║     🚛  СИСТЕМА ЛОГІСТИКИ ТА ПЛАНУВАННЯ ПЕРЕВЕЗЕНЬ  📦   ║
                ║                                                          ║
                ╚══════════════════════════════════════════════════════════╝
                """);
    }

    private void printMainMenu() {
        System.out.println("""
                ┌─────────────────── ГОЛОВНЕ МЕНЮ ──────────────────────┐
                │  1. 📦 Управління складом (вантажі)                   │
                │  2. 🚛 Управління транспортним парком                 │
                │  3. 👤 Управління водіями                             │
                │  4. 🗺️  Маршрути                                      │
                │  5. 📋 Замовлення та рейси                            │
                │  6. 💰 Рахунки-фактури (інвойси)                      │
                │  0. 🚪 Вихід                                          │
                └───────────────────────────────────────────────────────┘""");
    }


    private void warehouseMenu() {
        boolean back = false;
        while (!back) {
            System.out.println("""
                    ╔═══ 📦 УПРАВЛІННЯ СКЛАДОМ ════════════════════════════╗
                    │  1. Показати всі вантажі на складі                   │
                    │  2. Показати всі вантажі (будь-який статус)          │
                    │  3. Знайти вантаж за ID                              │
                    │  4. Пошук вантажу за назвою                          │
                    │  5. Додати новий вантаж                              │
                    │  0. Назад                                            │
                    ╚══════════════════════════════════════════════════════╝""");
            int c = readInt("Вибір: ");
            switch (c) {
                case 1 -> {
                    List<Cargo> list = cargoService.findAllOnWarehouse();
                    if (list.isEmpty()) info("Склад порожній.");
                    else list.forEach(cargo -> System.out.println("  " + cargo));
                }
                case 2 -> cargoService.findAll().forEach(cargo -> System.out.println("  " + cargo));
                case 3 -> {
                    Long id = readLong("ID вантажу: ");
                    try { System.out.println("  " + cargoService.findById(id)); }
                    catch (Exception e) { warn(e.getMessage()); }
                }
                case 4 -> {
                    String kw = readString("Пошуковий запит: ");
                    cargoService.searchByName(kw).forEach(c2 -> System.out.println("  " + c2));
                }
                case 5 -> addCargoWizard();
                case 0 -> back = true;
                default -> warn("Невірний вибір");
            }
            if (!back) System.out.println();
        }
    }

    private void addCargoWizard() {
        System.out.println("\n  ── Додавання нового вантажу ──");
        String name     = readString("  Назва вантажу: ");
        double weight   = readDouble("  Вага (кг): ");
        double volume   = readDouble("  Об'єм (м³): ");
        System.out.println("  Тип вантажу: 1-Стандартний  2-Крихкий  3-Небезпечний  4-Рефрижераторний");
        int typeChoice  = readInt("  Тип: ");
        CargoType type  = switch (typeChoice) {
            case 2 -> CargoType.FRAGILE;
            case 3 -> CargoType.DANGEROUS;
            case 4 -> CargoType.REFRIGERATED;
            default -> CargoType.STANDARD;
        };
        try {
            Cargo saved = cargoService.addCargo(name, weight, volume, type);
            success("Вантаж додано на склад: " + saved);
        } catch (Exception e) {
            warn("Помилка: " + e.getMessage());
        }
    }


    private void vehicleMenu() {
        boolean back = false;
        while (!back) {
            System.out.println("""
                    ╔═══ 🚛 ТРАНСПОРТНИЙ ПАРК ══════════════════════════════╗
                    │  1. Всі транспортні засоби                            │
                    │  2. Доступні транспортні засоби                       │
                    │  3. Знайти за ID                                      │
                    │  4. Додати транспортний засіб                         │
                    │  0. Назад                                             │
                    ╚═══════════════════════════════════════════════════════╝""");
            int c = readInt("Вибір: ");
            switch (c) {
                case 1 -> vehicleService.findAll().forEach(v -> System.out.println("  " + v));
                case 2 -> {
                    List<Vehicle> avail = vehicleService.findAvailable();
                    if (avail.isEmpty()) info("Немає доступних авто.");
                    else avail.forEach(v -> System.out.println("  " + v));
                }
                case 3 -> {
                    Long id = readLong("ID авто: ");
                    try { System.out.println("  " + vehicleService.findById(id)); }
                    catch (Exception e) { warn(e.getMessage()); }
                }
                case 4 -> addVehicleWizard();
                case 0 -> back = true;
                default -> warn("Невірний вибір");
            }
            if (!back) System.out.println();
        }
    }

    private void addVehicleWizard() {
        System.out.println("\n  ── Додавання нового авто ──");
        String plate = readString("  Номерний знак: ");
        System.out.println("  Тип: 1-Фургон  2-Вантажівка  3-Рефрижератор");
        int tc = readInt("  Тип: ");
        VehicleType type = switch (tc) {
            case 2 -> VehicleType.TRUCK;
            case 3 -> VehicleType.REFRIGERATOR_TRUCK;
            default -> VehicleType.VAN;
        };
        double maxW  = readDouble("  Вантажопідйомність (кг): ");
        double maxV  = readDouble("  Об'єм кузова (м³): ");
        double fuel  = readDouble("  Витрата палива (л/100км): ");
        try {
            Vehicle v = vehicleService.addVehicle(plate, type, maxW, maxV, fuel);
            success("Транспортний засіб додано: " + v);
        } catch (Exception e) {
            warn("Помилка: " + e.getMessage());
        }
    }


    private void driverMenu() {
        boolean back = false;
        while (!back) {
            System.out.println("""
                    ╔═══ 👤 УПРАВЛІННЯ ВОДІЯМИ ═════════════════════════════╗
                    │  1. Всі водії                                         │
                    │  2. Доступні водії                                    │
                    │  3. Знайти за ID                                      │
                    │  4. Додати водія                                      │
                    │  5. Обнулити втому водія (відпочинок)                 │
                    │  0. Назад                                             │
                    ╚═══════════════════════════════════════════════════════╝""");
            int c = readInt("Вибір: ");
            switch (c) {
                case 1 -> driverService.findAll().forEach(d -> System.out.println("  " + d));
                case 2 -> {
                    List<Driver> avail = driverService.findAvailable();
                    if (avail.isEmpty()) info("Немає доступних водіїв.");
                    else avail.forEach(d -> System.out.println("  " + d));
                }
                case 3 -> {
                    Long id = readLong("ID водія: ");
                    try { System.out.println("  " + driverService.findById(id)); }
                    catch (Exception e) { warn(e.getMessage()); }
                }
                case 4 -> {
                    System.out.println("\n  ── Додавання нового водія ──");
                    String fn = readString("  Ім'я: ");
                    String ln = readString("  Прізвище: ");
                    String li = readString("  Номер посвідчення: ");
                    try {
                        Driver d = driverService.addDriver(fn, ln, li);
                        success("Водія додано: " + d);
                    } catch (Exception e) { warn("Помилка: " + e.getMessage()); }
                }
                case 5 -> {
                    Long id = readLong("ID водія: ");
                    try {
                        Driver d = driverService.resetFatigue(id);
                        success("Втому водія скинуто. " + d);
                    } catch (Exception e) { warn(e.getMessage()); }
                }
                case 0 -> back = true;
                default -> warn("Невірний вибір");
            }
            if (!back) System.out.println();
        }
    }


    private void routeMenu() {
        boolean back = false;
        while (!back) {
            System.out.println("""
                    ╔═══ 🗺️  МАРШРУТИ ══════════════════════════════════════╗
                    │  1. Всі маршрути                                      │
                    │  2. Знайти за ID                                      │
                    │  3. Додати маршрут                                    │
                    │  0. Назад                                             │
                    ╚═══════════════════════════════════════════════════════╝""");
            int c = readInt("Вибір: ");
            switch (c) {
                case 1 -> routeService.findAll().forEach(r -> System.out.println("  " + r));
                case 2 -> {
                    Long id = readLong("ID маршруту: ");
                    try { System.out.println("  " + routeService.findById(id)); }
                    catch (Exception e) { warn(e.getMessage()); }
                }
                case 3 -> {
                    String origin = readString("  Пункт відправлення: ");
                    String dest   = readString("  Пункт призначення: ");
                    double dist   = readDouble("  Відстань (км): ");
                    try {
                        Route r = routeService.addRoute(origin, dest, dist);
                        success("Маршрут додано: " + r);
                    } catch (Exception e) { warn("Помилка: " + e.getMessage()); }
                }
                case 0 -> back = true;
                default -> warn("Невірний вибір");
            }
            if (!back) System.out.println();
        }
    }


    private void orderMenu() {
        boolean back = false;
        while (!back) {
            System.out.println("""
                    ╔═══ 📋 ЗАМОВЛЕННЯ ═════════════════════════════════════╗
                    │  1. Всі замовлення                                    │
                    │  2. Знайти замовлення за ID                           │
                    │  3. Створити нове замовлення                          │
                    │  4. Відправити в рейс (PENDING → IN_TRANSIT)          │
                    │  5. Підтвердити доставку (IN_TRANSIT → DELIVERED)     │
                    │  6. Скасувати замовлення                              │
                    │  0. Назад                                             │
                    ╚═══════════════════════════════════════════════════════╝""");
            int c = readInt("Вибір: ");
            switch (c) {
                case 1 -> {
                    List<Order> orders = orderService.findAll();
                    if (orders.isEmpty()) info("Замовлень ще немає.");
                    else orders.forEach(o -> System.out.println("  " + o));
                }
                case 2 -> {
                    Long id = readLong("ID замовлення: ");
                    try { printOrderDetails(orderService.findById(id)); }
                    catch (Exception e) { warn(e.getMessage()); }
                }
                case 3 -> createOrderWizard();
                case 4 -> {
                    Long id = readLong("ID замовлення для відправки: ");
                    try {
                        Order o = orderService.dispatchOrder(id);
                        success("Замовлення відправлено! Статус: " + o.getStatus().getDisplayName());
                    } catch (Exception e) { warn(e.getMessage()); }
                }
                case 5 -> {
                    Long id = readLong("ID замовлення для підтвердження доставки: ");
                    try {
                        Order o = orderService.confirmDelivery(id);
                        success("Доставку підтверджено! Статус: " + o.getStatus().getDisplayName());
                        info("Пробіг авто оновлено. Втома водія збільшена.");
                    } catch (Exception e) { warn(e.getMessage()); }
                }
                case 6 -> {
                    Long id = readLong("ID замовлення для скасування: ");
                    try {
                        Order o = orderService.cancelOrder(id);
                        success("Замовлення скасовано. Вантажі повернено на склад.");
                    } catch (Exception e) { warn(e.getMessage()); }
                }
                case 0 -> back = true;
                default -> warn("Невірний вибір");
            }
            if (!back) System.out.println();
        }
    }

    private void createOrderWizard() {
        System.out.println("\n  ══ Створення нового замовлення ══");

        System.out.println("\n  Доступні маршрути:");
        routeService.findAll().forEach(r -> System.out.println("    " + r));
        Long routeId = readLong("  ID маршруту: ");

        System.out.println("\n  Доступні транспортні засоби:");
        vehicleService.findAvailable().forEach(v -> System.out.println("    " + v));
        Long vehicleId = readLong("  ID транспортного засобу: ");

        System.out.println("\n  Доступні водії:");
        driverService.findAvailable().forEach(d -> System.out.println("    " + d));
        Long driverId = readLong("  ID водія: ");

        System.out.println("\n  Вантажі на складі:");
        cargoService.findAllOnWarehouse().forEach(c -> System.out.println("    " + c));
        System.out.println("  Введіть ID вантажів через кому (наприклад: 1,2,3):");
        String cargoInput = readString("  ID вантажів: ");

        List<Long> cargoIds = new ArrayList<>();
        try {
            for (String s : cargoInput.split(",")) {
                cargoIds.add(Long.parseLong(s.trim()));
            }
        } catch (NumberFormatException e) {
            warn("Невірний формат ID вантажів.");
            return;
        }

        try {
            Order order = orderService.createOrder(routeId, vehicleId, driverId, cargoIds);
            success("Замовлення №" + order.getId() + " створено успішно! Статус: " +
                    order.getStatus().getDisplayName());
            printOrderDetails(order);
        } catch (Exception e) {
            warn("Помилка при створенні замовлення: " + e.getMessage());
        }
    }

    private void printOrderDetails(Order o) {
        System.out.println();
        System.out.println("  ┌─ Деталі замовлення №" + o.getId() + " " + "─".repeat(35));
        System.out.printf("  │  Маршрут:   %s → %s (%.0f км)%n",
                o.getRoute().getOrigin(), o.getRoute().getDestination(), o.getRoute().getDistanceKm());
        System.out.printf("  │  Авто:      %s (%s)%n",
                o.getVehicle().getLicensePlate(), o.getVehicle().getVehicleType().getDisplayName());
        System.out.printf("  │  Водій:     %s%n", o.getDriver().getFullName());
        System.out.printf("  │  Статус:    %s%n", o.getStatus().getDisplayName());
        System.out.println("  │  Вантажі:");
        o.getCargos().forEach(c -> System.out.printf("  │    • %s (%.1f кг / %.1f м³)%n",
                c.getName(), c.getWeightKg(), c.getVolumeM3()));
        System.out.println("  └" + "─".repeat(57));
    }


    private void invoiceMenu() {
        boolean back = false;
        while (!back) {
            System.out.println("""
                    ╔═══ 💰 РАХУНКИ-ФАКТУРИ ════════════════════════════════╗
                    │  1. Сформувати інвойс для замовлення                  │
                    │  2. Знайти інвойс за ID замовлення                    │
                    │  0. Назад                                             │
                    ╚═══════════════════════════════════════════════════════╝""");
            int c = readInt("Вибір: ");
            switch (c) {
                case 1 -> {
                    Long id = readLong("ID замовлення: ");
                    try {
                        Invoice inv = invoiceService.generateInvoice(id);
                        System.out.println(inv.getDetailedInfo());
                    } catch (Exception e) { warn(e.getMessage()); }
                }
                case 2 -> {
                    Long orderId = readLong("ID замовлення: ");
                    Optional<Invoice> inv = invoiceService.findByOrderId(orderId);
                    if (inv.isPresent()) System.out.println(inv.get().getDetailedInfo());
                    else info("Інвойс для замовлення №" + orderId + " ще не сформовано.");
                }
                case 0 -> back = true;
                default -> warn("Невірний вибір");
            }
            if (!back) System.out.println();
        }
    }


    private int readInt(String prompt) {
        System.out.print(prompt);
        try {
            return Integer.parseInt(scanner.nextLine().trim());
        } catch (NumberFormatException e) {
            return -1;
        }
    }

    private Long readLong(String prompt) {
        System.out.print(prompt);
        try {
            return Long.parseLong(scanner.nextLine().trim());
        } catch (NumberFormatException e) {
            warn("Невірний формат числа.");
            return -1L;
        }
    }

    private double readDouble(String prompt) {
        System.out.print(prompt);
        try {
            return Double.parseDouble(scanner.nextLine().trim().replace(",", "."));
        } catch (NumberFormatException e) {
            warn("Невірний формат числа.");
            return 0.0;
        }
    }

    private String readString(String prompt) {
        System.out.print(prompt);
        return scanner.nextLine().trim();
    }

    private void info(String msg)    { System.out.println("  ℹ️  " + msg); }
    private void warn(String msg)    { System.out.println("  ⚠️  " + msg); }
    private void success(String msg) { System.out.println("  ✅ " + msg); }

    private void printGoodbye() {
        System.out.println("""

                ╔══════════════════════════════════════════════════════════╗
                ║  Дякуємо за використання Системи Логістики. До побачення!║
                ╚══════════════════════════════════════════════════════════╝
                """);
    }
}