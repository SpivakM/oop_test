package com.logistics.cargo_api.service;

import com.logistics.cargo_api.entity.*;
import com.logistics.cargo_api.entity.enums.*;
import com.logistics.cargo_api.exception.EntityNotFoundException;
import com.logistics.cargo_api.exception.InvalidStatusTransitionException;
import com.logistics.cargo_api.repository.OrderRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;

@Service
@RequiredArgsConstructor
public class OrderService {

    private final OrderRepository    orderRepository;
    private final RouteService       routeService;
    private final VehicleService     vehicleService;
    private final DriverService      driverService;
    private final CargoService       cargoService;

    @Transactional
    public Order createOrder(Long routeId, Long vehicleId, Long driverId, List<Long> cargoIds) {
        if (cargoIds == null || cargoIds.isEmpty()) {
            throw new IllegalArgumentException("Замовлення повинно містити хоча б один вантаж");
        }

        Route route = routeService.findById(routeId);

        Vehicle vehicle = vehicleService.findById(vehicleId);
        if (vehicle.getStatus() != VehicleStatus.AVAILABLE) {
            throw new InvalidStatusTransitionException(
                    "Транспортний засіб " + vehicle.getLicensePlate() +
                            " не доступний (статус: " + vehicle.getStatus().getDisplayName() + ")");
        }

        Driver driver = driverService.findById(driverId);
        driverService.validateDispatchable(driver);

        List<Cargo> cargos = cargoIds.stream()
                .map(id -> {
                    Cargo c = cargoService.findById(id);
                    if (c.getStatus() != CargoStatus.ON_WAREHOUSE) {
                        throw new InvalidStatusTransitionException(
                                "Вантаж '" + c.getName() + "' (ID=" + id +
                                        ") недоступний — статус: " + c.getStatus().getDisplayName());
                    }
                    return c;
                })
                .toList();

        vehicleService.validateCompatibility(vehicle, cargos);

        Order order = Order.builder()
                .route(route)
                .vehicle(vehicle)
                .driver(driver)
                .cargos(new java.util.ArrayList<>(cargos))
                .status(OrderStatus.PENDING)
                .createdAt(LocalDateTime.now())
                .build();

        return orderRepository.save(order);
    }

    @Transactional
    public Order dispatchOrder(Long orderId) {
        Order order = findById(orderId);

        if (order.getStatus() != OrderStatus.PENDING) {
            throw new InvalidStatusTransitionException(
                    order.getStatus().getDisplayName(), OrderStatus.IN_TRANSIT.getDisplayName());
        }

        order.setStatus(OrderStatus.IN_TRANSIT);
        order.setDepartedAt(LocalDateTime.now());

        vehicleService.updateStatus(order.getVehicle().getId(), VehicleStatus.BUSY);
        driverService.updateStatus(order.getDriver().getId(), DriverStatus.BUSY);

        for (Cargo cargo : order.getCargos()) {
            cargoService.updateStatus(cargo.getId(), CargoStatus.IN_TRANSIT);
        }

        return orderRepository.save(order);
    }


    @Transactional
    public Order confirmDelivery(Long orderId) {
        Order order = findById(orderId);

        if (order.getStatus() != OrderStatus.IN_TRANSIT) {
            throw new InvalidStatusTransitionException(
                    order.getStatus().getDisplayName(), OrderStatus.DELIVERED.getDisplayName());
        }

        order.setStatus(OrderStatus.DELIVERED);
        order.setDeliveredAt(LocalDateTime.now());

        double distanceKm = order.getRoute().getDistanceKm();

        vehicleService.addMileage(order.getVehicle().getId(), distanceKm);
        vehicleService.updateStatus(order.getVehicle().getId(), VehicleStatus.AVAILABLE);

        int fatigueIncrease = (int) Math.min(40, distanceKm / 50);
        driverService.increaseFatigue(order.getDriver().getId(), fatigueIncrease);
        driverService.updateStatus(order.getDriver().getId(), DriverStatus.AVAILABLE);


        for (Cargo cargo : order.getCargos()) {
            cargoService.updateStatus(cargo.getId(), CargoStatus.DELIVERED);
        }

        return orderRepository.save(order);
    }


    @Transactional
    public Order cancelOrder(Long orderId) {
        Order order = findById(orderId);

        if (order.getStatus() != OrderStatus.PENDING) {
            throw new InvalidStatusTransitionException(
                    "Скасувати можна лише замовлення зі статусом '" +
                            OrderStatus.PENDING.getDisplayName() + "'. " +
                            "Поточний статус: " + order.getStatus().getDisplayName());
        }

        order.setStatus(OrderStatus.CANCELLED);

        for (Cargo cargo : order.getCargos()) {
            cargoService.updateStatus(cargo.getId(), CargoStatus.ON_WAREHOUSE);
        }

        return orderRepository.save(order);
    }

    @Transactional(readOnly = true)
    public Order findById(Long id) {
        return orderRepository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("Замовлення", id));
    }

    @Transactional(readOnly = true)
    public List<Order> findAll() {
        return orderRepository.findAll();
    }

    @Transactional(readOnly = true)
    public List<Order> findByStatus(OrderStatus status) {
        return orderRepository.findByStatus(status);
    }
}