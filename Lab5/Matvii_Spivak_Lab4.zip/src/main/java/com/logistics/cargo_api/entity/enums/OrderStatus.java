package com.logistics.cargo_api.entity.enums;

import lombok.Getter;

@Getter
public enum OrderStatus {
    PENDING("Очікує відправлення"),
    IN_TRANSIT("В дорозі"),
    DELIVERED("Доставлено"),
    CANCELLED("Скасовано");

    private final String displayName;

    OrderStatus(String displayName) {
        this.displayName = displayName;
    }

}
